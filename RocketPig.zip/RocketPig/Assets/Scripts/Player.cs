﻿using UnityEngine;

public class Player : MonoBehaviour
{
	// how much you go uo when you fly
	public Vector2 fly = new Vector2(0, 300);
	
	// Update is called once per frame
	void Update ()
	{
		//fly when you hit space
		if (Input.GetKeyUp("space"))
		{
			GetComponent<Rigidbody2D>().velocity = Vector2.zero;
			GetComponent<Rigidbody2D>().AddForce(fly);
		}
		
		//die when you go off the screen
		Vector2 screenPosition = Camera.main.WorldToScreenPoint(transform.position);
		if (screenPosition.y > Screen.height || screenPosition.y < 0)
		{
			Die();
		}

		//exit if esc is hit
		if (Input.GetKey(KeyCode.Escape)) {
        	Application.Quit();
    	}
	}
	
	//die when you hit something
	void OnCollisionEnter2D(Collision2D other)
	{
		Die();
	}
	
	//die function
	void Die()
	{
		Application.LoadLevel(Application.loadedLevel);
	}
}